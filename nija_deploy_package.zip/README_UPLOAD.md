
NIJA_Trading_Bot - upload package for Render
--------------------------------------------

This zip contains:
 - vendor/coinbase_advanced_py/   (a SAFE STUB, not the real package)
 - nija_bot.py
 - start.sh
 - requirements.txt

IMPORTANT:
 - The vendored `coinbase_advanced_py` in this archive is a **stub** to avoid ModuleNotFoundError
   during deployment. It simulates balances and order placements and WILL NOT interact with Coinbase.
 - BEFORE using real funds replace `vendor/coinbase_advanced_py` in the repo with the actual
   extracted contents of coinbase-advanced-py==1.8.2 (downloadable from PyPI).
 - DO NOT commit your API keys. Use Render's Environment Variables to set API_KEY and API_SECRET.
 - For safety, deploy first with DRY_RUN=True in Render.

Upload instructions (GitHub web UI):
 1. Unzip this archive locally.
 2. In your GitHub repo, click "Add file" -> "Upload files".
 3. Upload the `vendor/coinbase_advanced_py` folder + `nija_bot.py` + `start.sh` + `requirements.txt`.
 4. Commit to main.
 5. On Render, set ENV vars: API_KEY, API_SECRET, DRY_RUN=True and deploy.

