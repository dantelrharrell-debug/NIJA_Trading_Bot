#!/bin/bash
set -e
python3 nija_bot.py
