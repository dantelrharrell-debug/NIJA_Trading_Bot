
#!/usr/bin/env python3
import sys
import os
import time

# Ensure vendored packages are importable
VENDOR_DIR = os.path.join(os.path.dirname(__file__), "vendor")
if VENDOR_DIR not in sys.path:
    sys.path.insert(0, VENDOR_DIR)

# Import vendored package
try:
    import coinbase_advanced_py as cb
    print("✅ Imported coinbase_advanced_py:", getattr(cb, "__version__", "unknown"))
except ModuleNotFoundError:
    raise SystemExit("❌ Module coinbase_advanced_py not found in vendor/ (Upload vendor/coinbase_advanced_py to repo).")

# Load API keys from environment (set these in Render; never commit them)
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
DRY_RUN = os.getenv("DRY_RUN", "True").lower() == "true"
TRADE_SYMBOLS = os.getenv("TRADE_COINS", "BTC-USD,ETH-USD").split(",")
TRADE_AMOUNT = float(os.getenv("TRADE_AMOUNT", "1"))

if not API_KEY or not API_SECRET:
    print("⚠️ Missing API_KEY or API_SECRET. Running in local stub mode (DRY_RUN).")
    # For safety, if keys missing, force DRY_RUN True
    DRY_RUN = True

try:
    # Initialize client (stub or real depending on vendored package)
    client = cb.Client(API_KEY, API_SECRET, sandbox=DRY_RUN)
    print("🚀 Coinbase client initialized (sandbox/dry_run={}):".format(DRY_RUN))
except AttributeError:
    raise SystemExit("❌ vendored coinbase_advanced_py does not expose 'Client'. Replace with correct package.")
except Exception as e:
    raise SystemExit(f"❌ Error initializing client: {e}")

def fetch_and_print():
    try:
        balances = client.get_account_balances()
        print("💰 Balances:", balances)
    except Exception as e:
        print("❌ Error fetching balances:", e)

def sample_trade_cycle():
    for symbol in TRADE_SYMBOLS:
        price = client.get_product_price(symbol)
        print(f"📈 {symbol} price: {price}")
        if not DRY_RUN:
            order = client.place_market_order(symbol, "buy", TRADE_AMOUNT)
            print("Order placed:", order)
        else:
            print("DRY_RUN enabled — not placing real order.")

if __name__ == '__main__':
    print("🔥 Starting Nija Trading Bot (stub). Press Ctrl+C to exit.")
    fetch_and_print()
    try:
        while True:
            sample_trade_cycle()
            time.sleep(10)
    except KeyboardInterrupt:
        print("👋 Exiting.")
